# Defect Report

**Status: no defects verified.** The suite and the provided test account could not be exercised: the environment this
was authored in had no network access to Proton, so no live exploration or test run took place. Nothing below is
claimed as observed, and no defects have been invented.

## Findings log
| # | Type | Title | Severity (reasoning) | Reproducibility | Evidence |
|---|---|---|---|---|---|
| - | - | (none confirmed yet) | - | - | - |

## Defect template
- **Title:**
- **Environment:** browser + version, OS, viewport, date/build
- **Severity / priority:** and why (user impact, workaround, frequency)
- **Preconditions:** account/data/state
- **Steps to reproduce:** minimal, deterministic
- **Expected vs actual:**
- **Evidence:** screenshot / video / mochawesome report / console log
- **Reproducibility:** always / often / intermittent (x of y runs)

## Hypotheses to confirm on first live run (NOT defects)
1. Login may show human verification after repeated attempts from automation - record the threshold.
2. Composer/message bodies are iframes - confirm selectors survive releases.
3. `cy.origin` across mail.proton.me / account.proton.me may need adjustments after sign-out redirects (AUTH-03).
4. Undo Send availability/window may differ by plan.
5. URL-hash advanced search keys (`keyword`, `from`) are an assumption.

If a run produces failures, classify each as (a) selector drift, (b) assumption wrong, (c) flake, or (d) genuine product defect;
only (d) goes into the log with evidence.
