# 4-5 Minute Walkthrough Script

**0:00 Intro (20s).** "Cypress + JavaScript suite for Proton Mail Web: 18 scenarios, risk-based, one or two real mailboxes."

**0:20 Strategy and cases (60s).** Show TEST_STRATEGY.md (risks: rate limits/human verification, cross-origin login, encrypted iframe UI, async delivery, shared mailboxes) and TEST_CASES.md: 36 cases, 18 automated, rest backlog/manual with reasons.

**1:20 Architecture (60s).** Tree: e2e specs, support/pages, selectors.js. `cy.session` caching, `cy.origin` for account.proton.me, optional second account, cleanup hook.

**2:20 Live run (80s).** `npm run cy:smoke`. Narrate COMP-01 and ASYNC-01 (toast/Undo appear and disappear, restored composer, final delivery, no blind sleeps; `waitForMessage` poll).

**3:40 Evidence and reports (30s).** Open `reports/index.html`: screenshots, video, flaky retry marking.

**4:10 Judgement and honesty (50s).** PR vs nightly, CI lock, backlog (API seeding, more page components). State which selectors needed fixing during first live run and which defects were actually found.
